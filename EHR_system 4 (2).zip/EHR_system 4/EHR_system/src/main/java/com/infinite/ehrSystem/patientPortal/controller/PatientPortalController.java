package com.infinite.ehrSystem.patientPortal.controller;

import com.infinite.ehrSystem.patientPortal.dto.PatientPortalDTO;
import com.infinite.ehrSystem.patientPortal.service.PatientPortalService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.UUID;

@Controller
@RequestMapping("/patient-portal")
public class PatientPortalController {

    private  final PatientPortalService patientPortalService;

    public PatientPortalController(
            PatientPortalService patientPortalService) {

        this.patientPortalService = patientPortalService;
    }

    @GetMapping
    public String dashboard(
            @RequestParam(required = false) UUID patientId,
            Model model) {

        if (patientId == null) {
            model.addAttribute("errorMessage", "Please provide a patientId parameter to view the portal. Example: /patient-portal?patientId=<patient-uuid>");
            return "error";
        }

        PatientPortalDTO portal = patientPortalService.getPatientPortalByPatientId(patientId);

        model.addAttribute("portal", portal);

        if (portal != null && portal.getPatient() != null && portal.getPatient().getDob() != null) {
            java.time.LocalDate dob = portal.getPatient().getDob();
            int age = java.time.Period.between(dob, java.time.LocalDate.now()).getYears();
            model.addAttribute("age", age);
        }

        if (portal != null && portal.getVaccinations() != null) {
            model.addAttribute("vaccinationCount", portal.getVaccinations().size());
            if (!portal.getVaccinations().isEmpty()) {
                model.addAttribute("lastVaccination", portal.getVaccinations().get(portal.getVaccinations().size() - 1));
            }
        }

        return "portal-dashboard";
    }
}