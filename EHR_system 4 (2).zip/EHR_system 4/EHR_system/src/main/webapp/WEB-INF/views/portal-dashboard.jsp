<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Patient Portal</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px; border-radius: 10px; margin-bottom: 30px; }
        .header h1 { font-size: 32px; margin-bottom: 10px; }
        .patient-box { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .patient-box p { margin: 8px 0; }
        .section { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .section h2 { color: #333; border-bottom: 2px solid #667eea; padding-bottom: 15px; margin-bottom: 20px; }
        .section h3 { color: #667eea; margin-top: 15px; font-size: 16px; }
        .empty { color: #999; font-style: italic; padding: 20px; text-align: center; }
        .record { background: #f9f9f9; padding: 15px; margin: 10px 0; border-left: 4px solid #667eea; border-radius: 4px; }
        .record p { margin: 5px 0; font-size: 14px; }
        .record strong { color: #333; }
        .status-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-normal { background: #d4edda; color: #155724; }
        .status-abnormal { background: #f8d7da; color: #721c24; }
        .status-pending { background: #fff3cd; color: #856404; }
        .btn { display: inline-block; background: #667eea; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin: 5px 5px 5px 0; font-size: 14px; }
        .btn:hover { background: #764ba2; }
        .logout { background: #dc3545; }
        .logout:hover { background: #c82333; }
        .button-group { text-align: center; margin: 30px 0; }
        @media (max-width: 768px) {
            .patient-box { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📋 Patient Portal - Medical Records</h1>
        <p>View your complete medical history, test results, prescriptions, and vaccination records</p>
    </div>

    <c:choose>
        <c:when test="${not empty portal and not empty portal.patient}">
            <!-- Patient Information Section -->
            <div class="patient-box">
                <div>
                    <strong>Patient ID:</strong><br/>
                    <span>${portal.patient.patientCode}</span>
                </div>
                <div>
                    <strong>Name:</strong><br/>
                    <span>${portal.patient.name}</span>
                </div>
                <div>
                    <strong>Age:</strong><br/>
                    <span>${age} years</span>
                </div>
                <div>
                    <strong>Gender:</strong><br/>
                    <span>${portal.patient.gender}</span>
                </div>
                <div>
                    <strong>Phone:</strong><br/>
                    <span>${not empty portal.patient.phone ? portal.patient.phone : 'N/A'}</span>
                </div>
                <div>
                    <strong>Blood Group:</strong><br/>
                    <span>${not empty portal.patient.bloodGroup ? portal.patient.bloodGroup : 'Not Specified'}</span>
                </div>
                <c:if test="${not empty portal.patient.guardianName}">
                    <div>
                        <strong>Guardian:</strong><br/>
                        <span>${portal.patient.guardianName}</span>
                    </div>
                </c:if>
            </div>

            <!-- Medical History Section -->
            <div class="section">
                <h2>📚 Medical History</h2>
                <c:choose>
                    <c:when test="${not empty portal.medicalHistories}">
                        <c:forEach var="history" items="${portal.medicalHistories}">
                            <div class="record">
                                <p><strong>Condition:</strong> ${history.condition}</p>
                                <p><strong>Treatment:</strong> ${history.treatment}</p>
                                <p><strong>Date:</strong> ${history.recordDate}</p>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No medical history recorded</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Allergies Section -->
            <div class="section">
                <h2>⚠️ Allergies</h2>
                <c:choose>
                    <c:when test="${not empty portal.allergies}">
                        <c:forEach var="allergy" items="${portal.allergies}">
                            <div class="record">
                                <p><strong>Allergen:</strong> ${allergy.allergenName}</p>
                                <p><strong>Reaction:</strong> ${allergy.reactionType}</p>
                                <p><strong>Severity:</strong> ${allergy.severity}</p>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No allergies recorded</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Diagnoses Section -->
            <div class="section">
                <h2>🩺 Diagnoses</h2>
                <c:choose>
                    <c:when test="${not empty portal.diagnoses}">
                        <c:forEach var="diagnosis" items="${portal.diagnoses}">
                            <div class="record">
                                <p><strong>Diagnosis:</strong> ${diagnosis.diagnosisName}</p>
                                <p><strong>ICD Code:</strong> ${diagnosis.icdCode}</p>
                                <p><strong>Date:</strong> ${diagnosis.diagnosisDate}</p>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No diagnoses recorded</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Lab Results Section -->
            <div class="section">
                <h2>🔬 Lab Results</h2>
                <c:choose>
                    <c:when test="${not empty portal.labResults}">
                        <c:forEach var="labResult" items="${portal.labResults}">
                            <div class="record">
                                <p><strong>Test:</strong> ${labResult.testName}</p>
                                <p><strong>Result:</strong> ${labResult.resultValue} ${labResult.unit}</p>
                                <p><strong>Status:</strong>
                                    <c:choose>
                                        <c:when test="${labResult.status == 'NORMAL'}">
                                            <span class="status-badge status-normal">NORMAL</span>
                                        </c:when>
                                        <c:when test="${labResult.status == 'ABNORMAL'}">
                                            <span class="status-badge status-abnormal">ABNORMAL</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="status-badge status-pending">${labResult.status}</span>
                                        </c:otherwise>
                                    </c:choose>
                                </p>
                                <p><strong>Test Date:</strong> ${labResult.testDate}</p>
                                <c:if test="${not empty labResult.referenceRange}">
                                    <p><strong>Reference Range:</strong> ${labResult.referenceRange}</p>
                                </c:if>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No lab results available</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Prescriptions Section -->
            <div class="section">
                <h2>💊 Prescriptions</h2>
                <c:choose>
                    <c:when test="${not empty portal.prescriptions}">
                        <c:forEach var="prescription" items="${portal.prescriptions}">
                            <div class="record">
                                <p><strong>Medication:</strong> ${prescription.medicationName}</p>
                                <p><strong>Dosage:</strong> ${prescription.dosage}</p>
                                <p><strong>Frequency:</strong> ${prescription.frequency}</p>
                                <p><strong>Duration:</strong> ${prescription.duration}</p>
                                <p><strong>Instructions:</strong> ${prescription.instructions}</p>
                                <p><strong>Issued Date:</strong> ${prescription.issuedDate}</p>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No prescriptions issued</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Vaccinations Section -->
            <div class="section">
                <h2>💉 Vaccinations</h2>
                <c:choose>
                    <c:when test="${not empty portal.vaccinations}">
                        <c:forEach var="vaccination" items="${portal.vaccinations}">
                            <div class="record">
                                <p><strong>Vaccine:</strong> ${vaccination.vaccineName}</p>
                                <p><strong>Dose:</strong> ${vaccination.dose}</p>
                                <p><strong>Date:</strong> ${vaccination.vaccinationDate}</p>
                                <p><strong>Location:</strong> ${vaccination.administeredBy}</p>
                                <c:if test="${not empty vaccination.nextDueDate}">
                                    <p><strong>Next Due:</strong> ${vaccination.nextDueDate}</p>
                                </c:if>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No vaccination records</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Doctor Notes Section -->
            <div class="section">
                <h2>📝 Doctor Notes</h2>
                <c:choose>
                    <c:when test="${not empty portal.doctorNotes}">
                        <c:forEach var="note" items="${portal.doctorNotes}">
                            <div class="record">
                                <p><strong>Note Type:</strong> ${note.noteType}</p>
                                <p><strong>Doctor ID:</strong> ${note.doctorId}</p>
                                <p><strong>Note:</strong> ${note.noteText}</p>
                                <p><strong>Date Recorded:</strong> ${note.createdAt}</p>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty">No doctor notes recorded yet</div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Action Buttons -->
            <div class="button-group">
                <a class="btn" href="${pageContext.request.contextPath}/patient-portal?patientId=${portal.patient.id}">Refresh</a>
                <a class="btn" href="javascript:window.print()">Print Records</a>
                <a class="btn logout" href="${pageContext.request.contextPath}/logout">Logout</a>
            </div>

        </c:when>
        <c:otherwise>
            <div class="section">
                <p style="text-align: center; color: #999;">No patient information available. Please contact the reception desk to register or provide a valid Patient ID.</p>
            </div>
        </c:otherwise>
    </c:choose>

</div>
</body>
</html>

