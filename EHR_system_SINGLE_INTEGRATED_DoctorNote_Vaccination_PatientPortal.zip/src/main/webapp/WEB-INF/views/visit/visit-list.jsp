<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
    <title>Visit Management</title>
</head>
<body>

<h2>Visit Management</h2>
<a href="${pageContext.request.contextPath}/visits/new">
    Open New Visit
</a>

<br><br>

<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr>
            <th>Visit Code</th>
            <th>Patient</th>
            <th>Visit Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
        <c:choose>

            <c:when test="${not empty visits}">
                <c:forEach items="${visits}" var="visit">

                    <tr>
                        <td>
                            <c:out value="${visit.visitCode}" />
                        </td>

                        <td>
                            <c:out value="${visit.patientCode}" />
                            -
                            <c:out value="${visit.patientName}" />
                        </td>

                        <td>
                            <c:out value="${visit.visitDate}" />
                        </td>

                        <td>
                            <c:out value="${visit.status}" />
                        </td>

                        <td>
                        <a href="${pageContext.request.contextPath}/visits/details/${visit.id}">
                                View
                            </a>

                            <c:if test="${visit.status eq 'OPEN'}">
                            <form action = "${pageContext.request.contextPath}/visits/close/${visit.id}" method="post">

                                    <button type="submit">
                                        Close
                                    </button>
                                </form>
                            </c:if>
                        </td>
                    </tr>

                </c:forEach>
            </c:when>

            <c:otherwise>
                <tr>
                    <td colspan="5" align="center">
                        No Visits Found
                    </td>
                </tr>
            </c:otherwise>

        </c:choose>
    </tbody>

</table>

</body>
</html>