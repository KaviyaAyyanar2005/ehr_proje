<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
    <title>Open Visit</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
        }

        .container {
            width: 500px;
            margin: 60px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        table {
            width: 100%;
        }

        td {
            padding: 12px;
        }

        td:first-child {
            font-weight: bold;
            width: 40%;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
        }

        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #007bff;
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body>

<div class="container">

    <h2>Open Visit</h2>

    <form action="${pageContext.request.contextPath}/visits/save"
          method="post">

        <table>

            <tr>
                <td>Patient ID</td>
                <td>
                    <input type="text"
                           name="patientId"
                           required>
                </td>
            </tr>

            <tr>
                <td>Doctor Name</td>
                <td>
                    <select name="doctorId"
                            required
                            class="form-control">
                        <option value="">Select Doctor</option>
                        <c:forEach var="doctor" items="${doctors}">
                            <option value="${doctor.id}">${doctor.username}</option>
                        </c:forEach>
                    </select>
                </td>
            </tr>

            <tr>
                <td>Visit Date &amp; Time</td>
                <td>
                    <input type="datetime-local"
                           name="visitDate"
                           required>
                </td>
            </tr>

            <tr>
                <td colspan="2">
                    <button type="submit">
                        Open Visit
                    </button>
                </td>
            </tr>

        </table>

    </form>

    <a class="back-link"
       href="${pageContext.request.contextPath}/visits">
        ← Back To Visit List
    </a>

</div>

</body>
</html>
