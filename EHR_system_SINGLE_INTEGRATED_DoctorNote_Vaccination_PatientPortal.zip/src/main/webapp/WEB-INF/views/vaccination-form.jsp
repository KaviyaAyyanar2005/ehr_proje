<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Record Vaccination</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f4f6f9;
            margin:0;
            padding:0;
        }

        .container{
            width:650px;
            margin:40px auto;
            background:white;
            padding:25px;
            border-radius:8px;
            box-shadow:0 2px 8px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            color:#2c3e50;
            margin-bottom:25px;
        }

        .form-group{
            margin-bottom:18px;
        }

        label{
            display:block;
            font-weight:bold;
            margin-bottom:8px;
            color:#333;
        }

        input,
        select{
            width:100%;
            padding:10px;
            border:1px solid #ccc;
            border-radius:5px;
            box-sizing:border-box;
            font-size:14px;
        }

        input[readonly]{
            background-color:#f0f0f0;
            cursor:not-allowed;
        }

        .btn{
            width:100%;
            background:#007bff;
            color:white;
            padding:12px;
            border:none;
            border-radius:5px;
            cursor:pointer;
            font-size:16px;
            font-weight:bold;
            margin-top:8px;
        }

        .btn:hover{
            background:#0056b3;
        }

        .btn-dashboard{
            background:#28a745;
            margin-top:14px;
            text-decoration:none;
            display:block;
            text-align:center;
            line-height:12px;
        }

        .btn-dashboard:hover{
            background:#218838;
        }

        .error-message{
            color:#dc3545;
            font-weight:bold;
            margin-bottom:15px;
            padding:10px;
            background-color:#f8d7da;
            border-radius:5px;
        }
    </style>

</head>

<body>

<div class="container">

    <h2>Record Vaccination</h2>

    <c:if test="${not empty errorMessage}">
        <div class="error-message">${errorMessage}</div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/vaccination-ui/save">
        <input type="hidden" name="patientId" value="${patientId}">

        <div class="form-group">
            <label>Patient ID</label>
            <input type="text" name="patientCode" value="${patientCode}" readonly>
        </div>

        <div class="form-group">
            <label>Patient Name</label>
            <input type="text" name="patientName" value="${patientName}" readonly>
        </div>

        <div class="form-group">
            <label>Vaccine Name</label>

            <select id="vaccineName" name="vaccineName" required>
                <option value="">Select Vaccine</option>
                <c:forEach var="v" items="${vaccines}">
                    <option value="${v.vaccineName}">${v.vaccineName}</option>
                </c:forEach>
            </select>

        </div>

        <div class="form-group">
            <label>Dose Number</label>
            <input type="number" id="doseNumber" name="doseNumber" min="1" placeholder="Enter Dose Number" required>
        </div>

        <div class="form-group">
            <label>Administered Date</label>
            <input type="date" id="administeredDate" name="administeredDate" required value="${administeredDateDefault}">
        </div>

        <div class="form-group">
            <label>Administered By</label>
            <input type="text" name="administeredBy" value="Dr. David" readonly>
        </div>

        <div class="form-group">
            <label>Next Due Date</label>
            <input type="date" id="nextDueDate" name="nextDueDate">
        </div>

        <script>
            (function(){
                const vaccineEl = document.getElementById('vaccineName');
                const dateEl = document.getElementById('administeredDate');
                const doseEl = document.getElementById('doseNumber');
                const nextDueEl = document.getElementById('nextDueDate');

                function compute() {
                    const vaccine = vaccineEl.value;
                    if (!vaccine) return;
                    const patientId = document.querySelector('input[name="patientId"]').value;
                    const administeredDate = dateEl.value;
                    const params = new URLSearchParams();
                    if (patientId) params.append('patientId', patientId);
                    params.append('vaccineName', vaccine);
                    if (administeredDate) params.append('administeredDate', administeredDate);

                    fetch(window.location.origin + '${pageContext.request.contextPath}/vaccination-ui/compute?' + params.toString())
                        .then(r => r.json())
                        .then(data => {
                            if (data.nextDoseNumber !== undefined) {
                                doseEl.value = data.nextDoseNumber;
                            }
                            if (data.nextDueDate) {
                                nextDueEl.value = data.nextDueDate;
                            } else {
                                nextDueEl.value = '';
                            }
                        })
                        .catch(err => {
                            console.error('compute error', err);
                        });
                }

                vaccineEl.addEventListener('change', compute);
                dateEl.addEventListener('change', compute);

                // initial compute if a vaccine is present after page load
                document.addEventListener('DOMContentLoaded', function(){
                    setTimeout(compute, 50);
                });
            })();
        </script>

        <button type="submit" class="btn">Save Vaccination</button>

        <a href="${pageContext.request.contextPath}/vaccination-ui/list?patientId=${patientId}" class="btn btn-dashboard">Dashboard</a>

    </form>

</div>

</body>
</html>
