package com.infinite.ehrSystem.patient.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/patient")
public class PatientMvcController {

    @GetMapping("/register-form")
    public String showPatientRegistrationForm() {
        return "patient-register";
    }

}

