package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.dto.AuthDTO;
import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.entity.UserStatus;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import com.infinite.ehrSystem.role.entity.Role;
import com.infinite.ehrSystem.role.repository.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    @Override
    public User register(AuthDTO authDTO) throws Exception {
        // Check if username already exists
        if (userRepository.existsByUsername(authDTO.getUsername())) {
            throw new Exception("Username already exists: " + authDTO.getUsername());
        }

        // Check if email already exists
        if (userRepository.existsByEmail(authDTO.getEmail())) {
            throw new Exception("Email already exists: " + authDTO.getEmail());
        }

        // Find the role (either by roleId or by role name)
        Role role = null;
        
        // Try to parse as UUID (roleId)
        try {
            UUID roleId = UUID.fromString(authDTO.getRole());
            role = roleRepository.findById(roleId)
                    .orElseThrow(() -> new Exception("Role not found with id: " + roleId));
        } catch (IllegalArgumentException e) {
            // If not a valid UUID, try to find by name
            role = roleRepository.findByName(authDTO.getRole())
                    .orElseThrow(() -> new Exception("Role not found: " + authDTO.getRole()));
        }

        // Create new user
        User user = new User();
        user.setUsername(authDTO.getUsername());
        user.setEmail(authDTO.getEmail());
        user.setPassword(authDTO.getPassword());
        user.setRole(role);
        user.setStatus(UserStatus.ACTIVE);
        user.setFailedAttempts(0);

        return userRepository.save(user);
    }

    @Override
    public User getUserById(UUID id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }

    @Override
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found with username: " + username));
    }
}
