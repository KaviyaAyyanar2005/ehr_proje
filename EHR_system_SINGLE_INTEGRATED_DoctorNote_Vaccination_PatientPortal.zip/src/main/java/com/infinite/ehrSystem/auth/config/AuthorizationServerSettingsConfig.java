package com.infinite.ehrSystem.auth.config;

// AuthorizationServerSettingsConfig removed: authorization server settings are not needed when
// authentication is disabled.
public class AuthorizationServerSettingsConfig {

}