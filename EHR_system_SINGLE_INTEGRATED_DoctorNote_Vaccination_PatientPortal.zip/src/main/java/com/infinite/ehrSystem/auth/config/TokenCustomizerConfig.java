package com.infinite.ehrSystem.auth.config;

// TokenCustomizerConfig removed: token customization is irrelevant when JWTs are not issued by this app.
public class TokenCustomizerConfig {

}