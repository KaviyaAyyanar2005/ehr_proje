package com.infinite.ehrSystem.auth.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        System.out.println("DASHBOARD HIT");

        // Authentication is removed; provide a default role for views.
        model.addAttribute("role", "ROLE_ANONYMOUS");

        return "dashboard";
    }
}