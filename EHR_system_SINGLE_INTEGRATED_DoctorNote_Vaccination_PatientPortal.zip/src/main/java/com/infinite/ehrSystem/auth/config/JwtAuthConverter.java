package com.infinite.ehrSystem.auth.config;

// JwtAuthConverter removed: JWT-based authentication is no longer used.
public class JwtAuthConverter {

}