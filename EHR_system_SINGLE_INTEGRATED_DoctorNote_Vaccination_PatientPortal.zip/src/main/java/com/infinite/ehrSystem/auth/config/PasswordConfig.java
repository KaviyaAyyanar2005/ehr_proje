package com.infinite.ehrSystem.auth.config;

// PasswordConfig removed: password encoding beans were part of security stack.
// Authentication has been disabled, so this configuration is intentionally empty.
public class PasswordConfig {

}