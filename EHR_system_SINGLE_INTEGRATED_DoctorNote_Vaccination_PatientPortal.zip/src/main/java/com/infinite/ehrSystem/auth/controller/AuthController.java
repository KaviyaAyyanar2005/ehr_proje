package com.infinite.ehrSystem.auth.controller;

import com.infinite.ehrSystem.auth.dto.AuthDTO;
import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.entity.UserStatus;
import com.infinite.ehrSystem.auth.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    /**
     * Simple session login used by the JSP application.
     * The current project intentionally has a permissive Spring Security
     * configuration, so the JSP flow keeps authentication state in session.
     */
    @PostMapping("/login")
    public String formLogin(
            @RequestParam String username,
            @RequestParam String password,
            HttpSession session) {

        try {
            User user = userService.getUserByUsername(username);

            if (user.getStatus() != UserStatus.ACTIVE ||
                    !user.getPassword().equals(password)) {
                return "redirect:/login?error=true";
            }

            session.setAttribute("loggedInUsername", user.getUsername());
            session.setAttribute("loggedInRole", user.getRole().getName());
            session.setAttribute("loggedInUserId", user.getId().toString());

            if ("PATIENT".equalsIgnoreCase(user.getRole().getName())) {
                return "redirect:/patient-portal";
            }

            return "redirect:/dashboard";
        } catch (Exception e) {
            return "redirect:/login?error=true";
        }
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?logout=true";
    }

    @PostMapping("/api/auth/register")
    @ResponseBody
    public ResponseEntity<?> register(@RequestBody AuthDTO authDTO) {
        try {
            User user = userService.register(authDTO);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "User registered successfully");
            response.put("user", new UserResponseDTO(
                    user.getId(),
                    user.getUsername(),
                    user.getEmail(),
                    user.getRole().getName(),
                    user.getStatus().toString()
            ));

            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", e.getMessage());

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    @PostMapping("/api/auth/login")
    @ResponseBody
    public ResponseEntity<?> apiLogin(@RequestBody AuthDTO authDTO) {
        try {
            User user = userService.getUserByUsername(authDTO.getUsername());

            if (user.getStatus() != UserStatus.ACTIVE ||
                    !user.getPassword().equals(authDTO.getPassword())) {
                throw new Exception("Invalid username or password");
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Login successful");
            response.put("user", new UserResponseDTO(
                    user.getId(),
                    user.getUsername(),
                    user.getEmail(),
                    user.getRole().getName(),
                    user.getStatus().toString()
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", e.getMessage());

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    public static class UserResponseDTO {
        public Object id;
        public String username;
        public String email;
        public String role;
        public String status;

        public UserResponseDTO(Object id, String username, String email, String role, String status) {
            this.id = id;
            this.username = username;
            this.email = email;
            this.role = role;
            this.status = status;
        }

        public Object getId() { return id; }
        public String getUsername() { return username; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
        public String getStatus() { return status; }
    }
}
