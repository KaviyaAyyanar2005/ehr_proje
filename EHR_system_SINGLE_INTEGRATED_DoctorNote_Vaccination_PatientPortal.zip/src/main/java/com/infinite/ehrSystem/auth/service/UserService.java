package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.dto.AuthDTO;
import com.infinite.ehrSystem.auth.entity.User;

import java.util.UUID;

public interface UserService {
    User register(AuthDTO authDTO) throws Exception;
    User getUserById(UUID id);
    User getUserByUsername(String username);
}
