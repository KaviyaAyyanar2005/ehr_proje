package com.infinite.ehrSystem.auth.config;

// RegisteredClientConfig removed: authorization server is not used when authentication is disabled.
public class RegisteredClientConfig {

}