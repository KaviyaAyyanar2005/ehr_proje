package com.infinite.ehrSystem.auth.service;

import org.springframework.stereotype.Service;

// CustomUserDetailsService removed: authentication is disabled. Keep a lightweight service
// placeholder so other components that may autowire it don't fail at runtime.
@Service
public class CustomUserDetailsService {

    // Intentionally left minimal. Authentication is disabled; user management is handled elsewhere.

}