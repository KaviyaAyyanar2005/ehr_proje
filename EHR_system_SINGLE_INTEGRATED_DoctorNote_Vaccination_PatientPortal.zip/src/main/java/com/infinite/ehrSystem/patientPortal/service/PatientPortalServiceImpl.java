package com.infinite.ehrSystem.patientPortal.service;

import com.infinite.ehrSystem.allergy.dto.AllergyDTO;
import com.infinite.ehrSystem.allergy.service.AllergyService;
import com.infinite.ehrSystem.doctorNote.dto.DoctorNoteDTO;
import com.infinite.ehrSystem.doctorNote.service.DoctorNoteService;
import com.infinite.ehrSystem.medicalhistory.dto.MedicalHistoryDto;
import com.infinite.ehrSystem.medicalhistory.service.MedicalHistoryService;
import com.infinite.ehrSystem.patient.dto.PatientDto;
import com.infinite.ehrSystem.patient.entity.Patient;
import com.infinite.ehrSystem.patient.repository.PatientRepository;
import com.infinite.ehrSystem.patientPortal.dto.PatientPortalDTO;
import com.infinite.ehrSystem.vaccination.dto.VaccinationDTO;
import com.infinite.ehrSystem.vaccination.service.VaccinationService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PatientPortalServiceImpl implements PatientPortalService {

    private final PatientRepository patientRepository;
    private final MedicalHistoryService medicalHistoryService;
    private final AllergyService allergyService;
    private final VaccinationService vaccinationService;
    private final DoctorNoteService doctorNoteService;

    public PatientPortalServiceImpl(
            PatientRepository patientRepository,
            MedicalHistoryService medicalHistoryService,
            AllergyService allergyService,
            com.infinite.ehrSystem.diagnosis.service.DiagnosisService diagnosisService,
            com.infinite.ehrSystem.labResults.service.LabResultService labResultService,
            com.infinite.ehrSystem.prescriptions.service.PrescriptionService prescriptionService,
            VaccinationService vaccinationService,
            DoctorNoteService doctorNoteService) {
        this.patientRepository = patientRepository;
        this.medicalHistoryService = medicalHistoryService;
        this.allergyService = allergyService;
        this.vaccinationService = vaccinationService;
        this.doctorNoteService = doctorNoteService;
    }

    @Override
    public PatientPortalDTO getPatientPortal(String username) {
        if (username == null || username.isBlank()) return null;

        Optional<Patient> patientOpt = patientRepository.findByPatientCode(username);

        // Backward compatibility for existing accounts that used phone as username.
        if (patientOpt.isEmpty()) {
            patientOpt = patientRepository.findByPhone(username);
        }

        return patientOpt.map(this::buildPortal).orElse(null);
    }

    @Override
    public PatientPortalDTO getPatientPortalByPatientId(UUID patientId) {
        if (patientId == null) return null;
        return patientRepository.findById(patientId)
                .map(this::buildPortal)
                .orElse(null);
    }

    private PatientPortalDTO buildPortal(Patient patient) {
        PatientDto patientDto = new PatientDto();
        patientDto.setId(patient.getId());
        patientDto.setPatientCode(patient.getPatientCode());
        patientDto.setName(patient.getName());
        patientDto.setDob(patient.getDob());
        patientDto.setGender(patient.getGender());
        patientDto.setPhone(patient.getPhone());
        patientDto.setGuardianName(patient.getGuardianName());
        patientDto.setBloodGroup(patient.getBloodGroup());

        UUID patientId = patient.getId();

        List<MedicalHistoryDto> histories = medicalHistoryService.getHistory(patientId);
        List<AllergyDTO> allergies = allergyService.getAllergies(patientId);
        List<VaccinationDTO> vaccinations = vaccinationService.getVaccinationsByPatientId(patientId);
        List<DoctorNoteDTO> doctorNotes = doctorNoteService.getNotesByPatientId(patientId);

        PatientPortalDTO portal = new PatientPortalDTO();
        portal.setPatient(patientDto);
        portal.setMedicalHistories(histories);
        portal.setAllergies(allergies);
        portal.setVaccinations(vaccinations);
        portal.setDoctorNotes(doctorNotes);

        // The current project has no patient-level query methods for these
        // modules, so keep the portal DTO fields populated safely until those
        // relationships are added to the corresponding services.
        portal.setDiagnoses(List.of());
        portal.setLabResults(List.of());
        portal.setPrescriptions(List.of());

        return portal;
    }
}
