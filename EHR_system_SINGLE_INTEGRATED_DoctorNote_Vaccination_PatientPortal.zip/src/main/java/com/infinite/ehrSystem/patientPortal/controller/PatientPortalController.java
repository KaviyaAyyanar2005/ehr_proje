package com.infinite.ehrSystem.patientPortal.controller;

import com.infinite.ehrSystem.patientPortal.dto.PatientPortalDTO;
import com.infinite.ehrSystem.patientPortal.service.PatientPortalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Controller
@RequestMapping("/patient-portal")
public class PatientPortalController {

    private final PatientPortalService patientPortalService;

    public PatientPortalController(PatientPortalService patientPortalService) {
        this.patientPortalService = patientPortalService;
    }

    /**
     * Patient's own portal. The patientId is deliberately not accepted here;
     * the logged-in patient identity comes from the server-side session.
     */
    @GetMapping
    public String dashboard(HttpSession session, Model model) {
        Object username = session.getAttribute("loggedInUsername");

        if (username == null) {
            return "redirect:/login?error=loginRequired";
        }

        Object role = session.getAttribute("loggedInRole");
        if (role == null || !"PATIENT".equalsIgnoreCase(role.toString())) {
            model.addAttribute("errorMessage", "Patient portal is available only for PATIENT accounts.");
            return "error";
        }

        PatientPortalDTO portal =
                patientPortalService.getPatientPortal(username.toString());

        if (portal == null || portal.getPatient() == null) {
            model.addAttribute("errorMessage",
                    "Patient profile is not linked to this login account.");
            return "error";
        }

        model.addAttribute("portal", portal);

        if (portal.getPatient().getDob() != null) {
            int age = java.time.Period.between(
                    portal.getPatient().getDob(),
                    java.time.LocalDate.now()).getYears();
            model.addAttribute("age", age);
        }

        model.addAttribute("vaccinationCount",
                portal.getVaccinations() == null ? 0 : portal.getVaccinations().size());

        return "portal-dashboard";
    }

    /**
     * Admin/doctor/lab-tech preview route. It remains separate from the
     * patient self-service route so a patient cannot select another ID.
     */
    @GetMapping("/preview")
    public String preview(@RequestParam UUID patientId, Model model) {
        PatientPortalDTO portal =
                patientPortalService.getPatientPortalByPatientId(patientId);

        if (portal == null) {
            model.addAttribute("errorMessage", "Patient not found.");
            return "error";
        }

        model.addAttribute("portal", portal);
        if (portal.getPatient().getDob() != null) {
            model.addAttribute("age",
                    java.time.Period.between(
                            portal.getPatient().getDob(),
                            java.time.LocalDate.now()).getYears());
        }
        model.addAttribute("vaccinationCount",
                portal.getVaccinations() == null ? 0 : portal.getVaccinations().size());

        return "portal-dashboard";
    }
}
