-- Optional helper for existing databases.
-- Hibernate ddl-auto=update will normally create the PATIENT role when the
-- first patient is registered. This script can be run manually if desired.

INSERT INTO roles (id, name)
SELECT UUID(), 'PATIENT'
WHERE NOT EXISTS (
    SELECT 1 FROM roles WHERE name = 'PATIENT'
);
