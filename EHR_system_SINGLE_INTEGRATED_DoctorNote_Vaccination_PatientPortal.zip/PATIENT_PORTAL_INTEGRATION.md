# EHR System - Single Integrated Project

This project contains the existing EHR modules in one Spring Boot application:

- Authentication / User / Role
- Admin
- Doctor
- Lab Technician
- Patient registration
- Doctor Notes backend + JSP pages
- Vaccination backend + JSP pages
- Patient Portal JSP + backend
- Medical History
- Allergy
- Diagnosis
- Lab Results
- Prescriptions
- Visits

## Patient login flow

1. Admin registers a patient using `POST /api/patients/register`.
2. The service creates the Patient record and generates a patient code such as `PAT-202609-1234`.
3. A `User` record is automatically created with role `PATIENT`.
4. `patients.user_id` links the patient record to that login account.
5. Patient logs in at `/login`.
6. Username is the generated patient code.
7. For this current demo authentication flow, the temporary password is the patient's 10-digit phone number.
8. A successful PATIENT login redirects automatically to `/patient-portal`.
9. The portal resolves the patient from the logged-in session username. It does not accept a patientId from the patient route, so a patient cannot select another patient's ID.
10. The portal displays the patient's profile, medical history, allergies, vaccinations and doctor notes.

## Important database change

`Patient` now has:

```java
@OneToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "user_id", unique = true)
private User user;
```

Because `spring.jpa.hibernate.ddl-auto=update` is enabled, Hibernate can add the column automatically.

## Existing JSP modules included

Doctor Notes:
- `/doctor-notes/form`
- `/doctor-notes/view`
- `/doctor-notes/save`

Vaccination:
- `/vaccination-ui/new`
- `/vaccination-ui/list`
- `/vaccination-ui/list/patient`
- vaccine master JSP pages

Patient Portal:
- `/patient-portal`

## Run

Use Java 17 and MySQL. Update `src/main/resources/application.properties` with your MySQL credentials.

From the project directory:

```bash
./mvnw spring-boot:run
```

or on Windows:

```bat
mvnw.cmd spring-boot:run
```

Open:

`http://localhost:8081/login`

## Notes

The supplied project currently has Spring Security configured permissively and uses a server-side HTTP session for the JSP login flow. This preserves the existing project's current authentication setup while connecting the new PATIENT account to the portal.

For a production deployment, passwords should be stored with BCrypt/Argon2 and the patient portal should use authenticated Spring Security principals rather than the demo session login.
